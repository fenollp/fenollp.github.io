#version 430 core
void main() {
  //...there appears to be nothing here...
}
